import java.util.Scanner;


public class Exerc2B {

	
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		int produtos;
		double total, valorfinal;
		
		System.out.println("Insira o valor total de produtos comprados");
		produtos = entrada.nextInt();
		System.out.println("insira o valor total da compra");
		total = entrada.nextDouble();
		
		if(produtos > 15  && total > 150){
			valorfinal = total * 1.25;
			System.out.println("O valor da compra é: "+ valorfinal);
		}
		else {
			System.out.println("O valor da compra é: "+total);
		}

	}

}
