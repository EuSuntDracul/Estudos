import java.util.Scanner;


public class Exerc3 {

	
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		int n1, n2, div;
		
		System.out.println("Insira o valor 1");
		n1 = entrada.nextInt();
		System.out.println("Insira o valor 2");
		n2 = entrada.nextInt();
		
		if(n1 == 0 || n2 ==0){
			System.out.println("O valor não pode ser dividido por zero");
		}
		else {
			div = n1 / n2;
			System.out.println("O valor da divisão é: "+div);
		}
		entrada.close();
	}

}
