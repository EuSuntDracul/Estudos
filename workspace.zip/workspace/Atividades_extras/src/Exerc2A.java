import java.util.Scanner;


public class Exerc2A {


	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double x, y, z;
		
		System.out.println("Insir ao valor de X");
		x = entrada.nextDouble();
		System.out.println("Insir ao valor de y");
		y = entrada.nextDouble();
		System.out.println("Insir ao valor de z");
		z = entrada.nextDouble();
		
		if (x > y || z <= 30){
			x = x*2;
			z = y / z;
			System.out.println("O valor de X é: "+ x);
			System.out.println("O valor de Z é: "+ z);
		}
		else{
			x = x/2;
			y = z/5;
			System.out.println("O valor de X é: "+x);
			System.out.println("O valor de Y é: "+y);
		}
		entrada.close();
	}

}
