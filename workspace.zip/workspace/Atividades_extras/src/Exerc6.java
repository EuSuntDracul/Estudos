import java.util.Scanner;


public class Exerc6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double compra, desconto;
		
		System.out.println("Insira o valor da compra");
		compra = entrada.nextDouble();
		
		if (compra >= 350.00){
			desconto = compra * 0.22;
			System.out.println("O valor do desconto é R$"+ desconto);
			compra = compra * 0.78;
			System.out.println("o valor da compra com desconto é: R$"+ compra);
		}
		else{
			desconto = compra * 0.15;
			System.out.println("O valor do desconto é: R$"+ desconto);
			compra = compra * 0.85;
			System.out.println("O valor da compra com desconto é: R$"+ compra);
		}
		entrada.close();

	}

}
