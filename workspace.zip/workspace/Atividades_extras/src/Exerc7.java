import java.util.Scanner;


public class Exerc7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double ValorImposto, Renda;
		
		System.out.println("insira o valor da renda");
		Renda = entrada.nextDouble();
		
		if(Renda <=10000){
			System.out.println("Está isento do valor do imposto");
		}
		else if(Renda > 10000 && Renda <= 25000){
			ValorImposto = Renda * 0.1035;
			System.out.println("O valor da aliquota é: "+ ValorImposto);
		}
		else if(Renda > 25000 && Renda <= 50000){
			ValorImposto = Renda * 0.2542;
			System.out.println("O valor da aliquota é: "+ ValorImposto);
		}
		else{
			ValorImposto = Renda * 0.2975;
			System.out.println("O valor da aliquota é: "+ ValorImposto);
		}
		entrada.close();

	}
	
}
