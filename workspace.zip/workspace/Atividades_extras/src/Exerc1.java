import java.util.Scanner;


public class Exerc1 {

	
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double x,y;
		
		System.out.println("Insira o valor de X");
		x = entrada.nextDouble();
		System.out.println("Insira o valor de Y");
		y = entrada.nextDouble();
		
		if (x > y){
			y = x*y;
			System.out.println("O valor de Y é: "+ y);
		}
		
		else if (x <= y && y != 7){
			x = x + y;
			System.out.println("O valor de X é: "+ x);
			y = y - 5;
			System.out.println("O valor de Y é: "+ y);
		}
		
		else{
			y = x - y;
			System.out.println("O valor de Y é: "+ y);
		}
		entrada.close();
	}

}
