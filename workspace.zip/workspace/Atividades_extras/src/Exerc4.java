import java.util.Scanner;


public class Exerc4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		int n1, n2;
		
		System.out.println("Insira o valor do primeiro número");
		n1 = entrada.nextInt();
		
		System.out.println("Insira o valor do segundo número");
		n2 = entrada.nextInt();
		
		if (n1 % n2 == 0){
			System.out.println("Os valores são multiplos");
		}
		else {
			System.out.println("Os valores não são multiplos");
		}
		entrada.close();

	}

}
