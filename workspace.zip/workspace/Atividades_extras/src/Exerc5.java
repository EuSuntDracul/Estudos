import java.util.Scanner;


public class Exerc5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double salario, vendas;
		
		System.out.println("Insira o valor das vendas");
		vendas = entrada.nextDouble();
		
		if (vendas > 25000){
			salario = vendas * 1.0885 - vendas;
			System.out.println("O valor do salário é: "+ salario);
		}
		else {
			salario = vendas * 1.175 - vendas;
			System.out.println("O valor do salário é: "+ salario);
		}
		entrada.close();
		
	}
	

}
