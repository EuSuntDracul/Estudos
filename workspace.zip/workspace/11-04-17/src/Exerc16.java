import java.util.Scanner;


public class Exerc16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		int valor;
		
		System.out.println("insira um valor inteiro");
		valor = entrada.nextInt();
		
		if(valor % 2 == 0){
			System.out.println("O número é par");
		}
		else{
			System.out.println("O valor é impar");
		}
		entrada.close();
	}

}
