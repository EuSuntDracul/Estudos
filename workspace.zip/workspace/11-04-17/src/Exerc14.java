import java.util.Scanner;


public class Exerc14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		String letra;
		
		System.out.println("Insira uma letra");
		letra = entrada.next();
		
		letra = letra.toLowerCase();
		if (letra.equals("a") || letra.equals("e") || letra.equals("i") || letra.equals("o") || letra.equals("u")){
			System.out.println("A vogal é: "+ letra);
		}
		else{
			System.out.println("A letra não é vogal!!");
		}
		entrada.close();

	}

}
