import java.util.Scanner;


public class Exercicio2_selmini {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String nome, genero;
		double altura, peso;

		System.out.println("Informe o gênero do paciente (masculino ou feminino)");
		genero = entrada.next();
		
		if(!genero.equalsIgnoreCase("feminino") && !genero.equalsIgnoreCase("Masculino")){
			System.out.println("Genero inválido para essa variavel");
		}
		else {
			System.out.println("Informe o nome do paciente");
			entrada.nextLine();
			nome = entrada.nextLine();
			System.out.println("informe a altura do paciente");
			altura = entrada.nextDouble();
			if (genero.equalsIgnoreCase("feminino")){
				peso = 62.1*altura-44.7;
			}
			else {
				peso = 72.7*altura-58;
			}
			System.out.println(nome +"seu peso ideal é "+peso);
		}
	}
}
