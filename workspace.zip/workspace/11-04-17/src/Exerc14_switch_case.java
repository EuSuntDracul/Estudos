import java.util.Scanner;


public class Exerc14_switch_case {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		String letra;
		
		System.out.println("Insira uma letra");
		letra = entrada.next();
		
		letra = letra.toLowerCase();
		
		switch (letra) {
		case "a":
		case "e":
		case "i":
		case "o":
		case "u":
			System.out.println("É uma vogal");
			break;

		default:
			System.out.println("Não é uma vogal");
			break;
		}
		entrada.close();
	
		}
	}


