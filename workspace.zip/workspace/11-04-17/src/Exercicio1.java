import java.util.Scanner;


public class Exercicio1 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		int dias;
		double valor;
		
		System.out.println("Insira a quantidade de dias");
		dias = entrada.nextInt();
		
		if (dias > 15){
			valor =  dias * 150 + dias * 15.50;
			System.out.println("O valor total é: "+ valor);
		}
		else if (dias == 15){
			valor = dias * 150 + dias * 36; 
			System.out.println("O valor total é: "+ valor);
		}
		else{
			valor = dias * 150 + dias * 58;
			System.out.println("O valor total é: "+ valor);
		}
	}

}
