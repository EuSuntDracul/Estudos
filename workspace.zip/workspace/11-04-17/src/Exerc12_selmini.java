import java.util.Scanner;


public class Exerc12_selmini {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
Scanner entrada = new Scanner (System.in);
		
		int n1, n2, n3, aux;
		
		System.out.println("Insira o primeiro Valor");
		n1 = entrada.nextInt();
		System.out.println("Insira o segundo Valor");
		n2 = entrada.nextInt();  
		System.out.println("Insira o terceiro Valor");
		n3 = entrada.nextInt();
		
		if(n1 > n2){
			aux = n1;
			n1 = n2;
			n2 = aux;
		}
		if(n1 > n3){
			aux = n1;
			n1 = n3;
			n3 = aux;
		}
		if (n2 > n3){
			aux = n2;
			n2 = n3;
			n3 = aux;
		}
		System.out.println(n1+" "+n2+" "+n3);
	}

}
