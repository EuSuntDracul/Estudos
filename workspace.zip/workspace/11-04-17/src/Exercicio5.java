import java.util.Scanner;


public class Exercicio5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		String cargo;
		double salario, diferenca, tempo, salariofinal;
		
		System.out.println("informe o cargo exercido");
		cargo = entrada.nextLine();
			if (cargo.equalsIgnoreCase("gerente")){
				System.out.println("Insira o tempo de serviço");
				tempo = entrada.nextDouble();
				
				if (tempo >= 5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.10;
														
				}
				else if (tempo >=3 && tempo <5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.09;
					
				}
				else{
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.8;
					
				}
				
				System.out.println("O novo salário é: "+ salariofinal);
				diferenca = salariofinal - salario;
				System.out.println("A diferença em relação ao anteior é: "+ diferenca);
			}
			else if(cargo.equalsIgnoreCase("engenheiro")){
					System.out.println("Insira o tempo de serviço");
					tempo = entrada.nextDouble();
					
					if (tempo >= 5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.11;
					}
					else if (tempo >=3 && tempo <5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.10;
								
					}
					else{
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.8;
					
					}
					
					System.out.println("O novo salário é: "+ salariofinal);
					diferenca = salariofinal - salario;
					System.out.println("A diferença em relação ao anteior é: "+ diferenca);
			}
			else if(cargo.equalsIgnoreCase("tecnico")){
					System.out.println("Insira o tempo de serviço");
					tempo = entrada.nextDouble();
					
					if	(tempo >= 5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.11;
					}
					
					else if (tempo >=3 && tempo <5){
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.10;
					}
					
					else{
					System.out.println("Insira o valor do salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.8;
					}
					
					System.out.println("O novo salário é: "+ salariofinal);
					diferenca = salariofinal - salario;
					System.out.println("A diferença em relação ao anteior é: "+ diferenca);
			}
			else{
					System.out.println("Insira o salário");
					salario = entrada.nextDouble();
					salariofinal = salario * 1.05;
					diferenca = salariofinal - salario;
				
					System.out.println("O valor do salario final é: "+ salariofinal);
					System.out.println("O valor da diferença é: "+ diferenca);
			}
			entrada.close();
	}
}
