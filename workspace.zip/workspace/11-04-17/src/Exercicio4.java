import java.util.Scanner;


public class Exercicio4 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		double a, b, c, delta, x1, x2;
		
		System.out.println("Insira o valor de A");
		a = entrada.nextDouble();
			if (a == 0 ){
				System.out.println("Não é uma equação de segundo grau");
			}
			
			else {
				System.out.println("Insira o valor de B");
				b = entrada.nextDouble();
				
				System.out.println("Insira o valor de C");
				c = entrada.nextDouble();
				
				
				delta = b*b - 4*a*c;
				if(delta < 0){
					System.out.println("A equação não tem raiz real");
				}
				else{
					x1 = (-b + Math.sqrt(delta))/(2*a);
					x2 = (-b - Math.sqrt(delta))/(2*a);
					
					System.out.println("Os valores de x1 e x2 é: "+ x1);
					System.out.println("Os valores de x1 e x2 é: "+ x2);
				}
				
				
				
			}
		
		
		
		

	}

}
