import java.util.Scanner;


public class Exerc15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);

		int n1, n2, resultado, operador;
		
		System.out.println("Digite o número correspondente à operação: 1- Adição / 2 - Subtração / 3 - Multiplicação / 4 - Divisão");
		operador = entrada.nextInt();
		
		if (operador <= 0 || operador >= 5){
			System.out.println("Valor inválido");			
		}
		else{
			System.out.println("Insira o valor 1");
			n1 = entrada.nextInt();
			System.out.println("Insira o valor 2");
			n2 = entrada.nextInt();
			
			switch (operador) {
			case 1:
				resultado = n1 + n2;
				System.out.println("O resultado é: "+resultado);
				break;
			case 2:
				resultado = n1 - n2;
				System.out.println("O resultado é: "+resultado);
				break;
			case 3: 
				resultado = n1 * n2;
				System.out.println("O resultado é: "+resultado);
				break;
			case 4: 
				if (n1 == 0 || n2 == 0){
					System.out.println("Não existe divisão por 0");
				}
				else{
					resultado = n1 / n2;
					System.out.println("O resultado é: "+resultado);
				}
				break;
			default:
				break;
		}
		
		
		}
		entrada.close();
		
	}

}
