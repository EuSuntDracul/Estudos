import java.util.Scanner;


public class Exercicio2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		String nome;
		int genero;
		double altura, PI;
				
		System.out.println("Insira seu nome");
		nome = entrada.nextLine();
		
		System.out.println("Por favor insira sua altura em metros");
		altura = entrada.nextDouble();
		
		System.out.println("Insira 1 para masculino e 0 para feminino");
		genero = entrada.nextInt();
		
		if (genero > 0){
			PI = 72.7*altura-58;
			System.out.println("O peso ideal para o homem é: "+PI);
	}
		else {
			PI = 62.1*altura-44.7;
			System.out.println("O peso ideial para a mulher é: "+PI);
		}
		
		entrada.close();

	}
}
