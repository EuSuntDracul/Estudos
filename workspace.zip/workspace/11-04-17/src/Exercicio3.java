import java.util.Scanner;


public class Exercicio3 {

	
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		int valor1, valor2, valor3;
		
		System.out.println("informe o primeiro valor inteiro");
		valor1 = entrada.nextInt();
		System.out.println("informe o segundo valor inteiro");
		valor2 = entrada.nextInt();
		System.out.println("informe o terceiro valor inteiro");
		valor3 = entrada.nextInt();
		
		if (valor1 != valor2 && valor1 != valor3 && valor2 != valor3){
			if (valor1 < valor2 && valor1 < valor3){
				System.out.println("O menor valor é: "+valor1);
			}
			else if (valor2 < valor1 && valor2 < valor3){
				System.out.println(valor2);
				
			}
			else {
				System.out.println(valor3);
			}
		
			entrada.close();
		}
		else {
			System.out.println("Os valores devem ser diferentes!!");
		}
	}

}
