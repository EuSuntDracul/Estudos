import java.util.Scanner;


public class Exerc16_ex2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		int valor;
		
		System.out.println("insira um valor inteiro");
		valor = entrada.nextInt();
		
		switch (valor%2) {
		case 0:
			System.out.println("O número é par");
			break;

		default:
			System.out.println("O valor é impar");
			break;
		}
		entrada.close();
	}
}
