import java.util.Scanner;


public class Exerc16_ex3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		int valor;
		
		System.out.println("insira um valor inteiro");
		valor = entrada.nextInt();
		
		System.out.println(valor%2 == 0 ? "Par" : "impar"); 
		entrada.close();
		}
		
}
