import java.util.Scanner;


public class Exerc12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		int n1, n2, n3, MenorValor, MaiorValor, Meio;
		
		System.out.println("Insira o primeiro Valor");
		n1 = entrada.nextInt();
		System.out.println("Insira o segundo Valor");
		n2 = entrada.nextInt();  
		System.out.println("Insira o terceiro Valor");
		n3 = entrada.nextInt();
		
		
		if(n1 == n2 || n1 == n3 || n2 == n3){
			System.out.println("Os valores devem ser diferentes!!");		
			
		}
		else if (n1 < n2){
			MenorValor = n1;
			Meio = n2;
			
			if (n1 > n2) {
				MenorValor = n2;
				Meio = n1;
			}
			else if (n1 < n3){
				MenorValor = n1;
				
			}
				
		}
		
	}

}
